#' Kinship matrix - Astle & Balding method
#'
#' This function computes a kinship matrix starting from a SNP one. It
#' uses the Astle and Balding iterative
#' approach (even if usually one iteration is enough).
#'
#' @param data matrix or dataframe, n rows (samples), m columns (markers), 0/1/2 content
#'
#' @return a kinship matrix with same colnames and rownames as \code{data}
#' @export
#' @example
#' not yet

kinship.AB = function (data){
  #individuals names
  indiv_names = rownames(data)

  #first instance of p is allele frequency from data
  p_hat = colSums(data) / (nrow(data)*2)

  #we remove markers that never change, since they bring
  #no information
  data = data[,(p_hat!=0) & (p_hat!=1)]

  #and update p_hat again for dimensionality
  p_hat = colSums(data) / (nrow(data)*2)

  #handy variables. for clarity
  samples_cnt = nrow(data)
  markers_cnt = ncol(data) #this is called L in the paper

  ##### COMPUTING K #####
  #this denominator is standard over all markers
  den = 4*p_hat*(1-p_hat)
  #making room for the new kinship matrix
  K_hat = matrix(0, nrow=samples_cnt, ncol=samples_cnt)

  #correcting data for allele frequency, it is equivalent
  #to subtracting, for each column, the corresponding element
  #of p_hat (adjusted for ploidy)
  data.old = data
  data = sweep(data, MARGIN=2, 2*p_hat)

  #for each marker contribution
  for (l in 1:markers_cnt){
    num = data[,l] %*% t(data[,l])
    K_hat = K_hat + num / den[l]
  }

  #average on L
  K_hat = K_hat / markers_cnt

  #reporting names
  rownames(K_hat) = indiv_names
  colnames(K_hat) = indiv_names

  return (K_hat)
}


#' Kinship matrix - Van Raden method
#'
#' This function computes a kinship matrix starting from a SNP one. It
#' uses the Van Raden approach.
#'
#' @param data matrix or dataframe, n rows (samples), m columns (markers), 0/1/2 content
#'
#' @return a kinship matrix with same colnames and rownames as \code{data}
#' @export

kinship.VR = function (data){
  #computing allele frequencies (p) for each marker
  p = colSums(data) / (nrow(data)*2)

  #scaling p so that heterozygotes are 0, homozygotes are +1 and -1
  p.scaled = 2 * (p - 0.5)

  #the Z matrix is obtained subtracting from the genotype matrix (in -1/0/+1 form)
  #a matrix reporting for each column the corresponding p.scaled value
  Z = as.matrix((data - 1) - matrix(rep(p.scaled, nrow(data)), nrow = nrow(data), byrow = TRUE))

  #the kinship matrix is ZZ' divided by a further scaling factor
  #kin = (Z %*% t(Z)) / (2 * sum(p * (1-p)))
  kin = tcrossprod(Z) / (2 * sum(p * (1-p)))

  #and we are done
  return(kin)
}

#' Function calculate genomic relationship matrix à la Van Raden
#'
#' This function allows you to set up the G-matrix à la Van Raden
#' @param M: n x m matrix of 0/1/2 coded SNP genotypes
#' @keywords g-matrix, van Raden
#' @export
#' @examples
#' gVanRaden(matrix(sample(c(0,1,2),200,replace=TRUE), nrow=10))
#'

gVanRaden.2 <- function(M) {

	# COMPUTE ALLELE FREQUENCIES
	p = colSums(M) / (nrow(M)*2)
	p.scaled = 2 * (p - 0.5)

	## BUILD MATRIX OF GENOMIC RELATIONSHIPS
	M <- as.matrix((M-1))-matrix(rep(p.scaled,nrow(M)),nrow=nrow(M),byrow=TRUE)

	GVR<-tcrossprod(M)/(2*sum(p*(1-p)));

	GVR <- rescale(GVR,0,2);
	return(GVR)
}


#' Function calculate genomic relationship matrix à la Astle & Balding (2009)
#' !!For data.table data structures!!
#'
#' This function allows you to set up the G-matrix à la Astle & Balding (2009)
#' @param M: n x m matrix of 0/1/2 coded SNP genotypes
#' @keywords g-matrix, Astle & Balding
#' @export
#' @examples
#' gAstleBalding(matrix(sample(c(0,1,2),200,replace=TRUE), nrow=10))
#'

gAstleBalding.2 <- function(M) {

  # COMPUTE ALLELE FREQUENCIES
  #first instance of p is allele frequency from data
  p_hat = colSums(M) / (nrow(M)*2)

  #we remove markers that never change, since they bring
  #no information
  M = M[,(p_hat!=0) & (p_hat!=1),with=FALSE]

  #and update p_hat again for dimensionality
  p_hat = colSums(M) / (nrow(M)*2)

  #handy variables. for clarity
  samples_cnt = nrow(M)
  markers_cnt = ncol(M) #this is called L in the paper

  ##### COMPUTING K #####
  #this denominator is standard over all markers
  den = 4*p_hat*(1-p_hat)
  #making room for the new kinship matrix
  K_hat = matrix(0, nrow=samples_cnt, ncol=samples_cnt)

  #correcting data for allele frequency, it is equivalent
  #to subtracting, for each column, the corresponding element
  #of p_hat (adjusted for ploidy)
  M = sweep(M, MARGIN=2, 2*p_hat)

  #for each marker contribution
  for (l in 1:markers_cnt){
    num = M[,l] %*% t(M[,l])
    K_hat = K_hat + num / den[l]
  }

  #average on L
  K_hat = K_hat / markers_cnt

	# library("scales")
	GAB <- rescale(K_hat,0,2);

	return(GAB)
}

#' Function to rescale data
#'
#' This function allows you to rescale your data between a new minimum and maximum (new range)
#' @param x vector of data (numeric),
#' @param newMin (integer)
#' @param newMax (integer)
#' @keywords rescale
#' @export
#' @examples
#' rescale(sample(runif(100),20),0,100)
#'

rescale <- function(x,newMin,newMax) {

  oldMax <-max(x);
  oldMin <-min(x);
  return((((newMax-newMin)*(x-oldMin))/(oldMax-oldMin))+newMin)
}

