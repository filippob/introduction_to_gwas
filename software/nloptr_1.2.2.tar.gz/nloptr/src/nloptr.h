#include <R.h>
#include <Rdefines.h>

#ifndef __NLOPTR_H__
#define __NLOPTR_H__

SEXP NLoptR_Optimize( SEXP args );

#endif /*__NLOPTR_H__*/
