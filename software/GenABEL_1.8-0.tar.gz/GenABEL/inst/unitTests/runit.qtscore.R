#library(GenABEL)
#data(ge03d2.clean)
#qtsOld <- qtscore(height~sex,data=ge03d2.clean,old=TRUE)
#qtsNew <- qtscore(height~sex,data=ge03d2.clean,old=FALSE)
