"cross" <-
function(a,b) {
	sum(!is.na(match(a,b)))
}

