#ifndef __FRVERSION__
#define __FRVERSION__

#define FV_VERSION "0.0-7"
#define FV_RELEASEDATE "July 26, 2009"
#define FV_AUTHORS "Yurii Aulchenko"

#endif
